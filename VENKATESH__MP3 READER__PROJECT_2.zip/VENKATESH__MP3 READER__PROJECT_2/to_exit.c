#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "tag.h"
#define RED "\033[1;31m"
#define GREEN "\033[1;32m"
#define YELLOW "\033[1;33m"
#define BLUE "\033[1;34m"
#define RESET "\033[0m"

void to_exit(struct mp3_tag *meta_data)
{
    int i; 
    for(i = 1; i <= 100; i++)
    {
        printf(YELLOW "\r[Exiting.....%d%%]" RESET, i);
        fflush(stdout);
        usleep(100000);   // 100ms for smoother progress bar
    }
    printf("\n");
    printf(GREEN "Exited successfully\n" RESET);
    exit(0);
}
