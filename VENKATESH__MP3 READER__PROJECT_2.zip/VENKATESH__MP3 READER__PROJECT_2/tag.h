#ifndef MP3_TAG_H
#define MP3_TAG_H
#define RED "\033[1;31m"
#define GREEN "\033[1;32m"
#define YELLOW "\033[1;33m"
#define BLUE "\033[1;34m"
#define RESET "\033[0m"

struct mp3_tag
{
    char tag[5];
    int size;
    char *tag_data;
};

void to_view(struct mp3_tag *meta_data);
void to_edit(struct mp3_tag *meta_data);
int validate_name(const char *str); 
void to_exit(struct mp3_tag *meta_data);

#endif