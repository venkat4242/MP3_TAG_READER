#include <stdio.h>
#include <stdlib.h>
#include "tag.h"
#define RED "\033[1;31m"
#define GREEN "\033[1;32m"
#define YELLOW "\033[1;33m"
#define BLUE "\033[1;34m"
#define RESET "\033[0m"

int main()
{
    int choice;
    struct mp3_tag meta_data;
    printf("==============MP3-TAG READER AND EDITOR=============\n");

    do
    {
        printf(BLUE "1. To View(-v)\n" RESET);
        printf(BLUE "2. To Edit(-e)\n" RESET);
        printf(BLUE "3. Exit\n" RESET);
        printf(YELLOW "Enter your choice: " RESET);
        scanf("%d", &choice);
        getchar();
        switch (choice)
        {
            case 1:
            to_view(&meta_data);
            break;

            case 2: 
            to_edit(&meta_data);
            break;

            case 3:
            to_exit(&meta_data);
            break;
        
            default:
            printf(RED "Choose the correct choice !\n" RESET);
        }
    }while(choice != 3);

    return 0;
}