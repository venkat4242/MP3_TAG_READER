#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "tag.h"
#define RED "\033[1;31m"
#define GREEN "\033[1;32m"
#define YELLOW "\033[1;33m"
#define BLUE "\033[1;34m"
#define RESET "\033[0m"


void update(struct mp3_tag *meta_data, char *new_data, char *name, char *frame)
{
    FILE *f1 = fopen(name, "r");
    if(f1 == NULL)
    {
        printf(RED "File not opened successfully !" RESET);
        return;
    }

    FILE *f2 = fopen("new.mp3", "w");
    if(f2 == NULL)
    {
        printf(RED "New file not created!\n" RESET);
        fclose(f1);
        return;
    }

    char header[10];
    fread(header, 1, 10, f1);
    fwrite(header, 1, 10, f2);

    while(fread(meta_data->tag, 1, 4, f1) == 4)
    {
        meta_data->tag[4] = '\0';

        if(meta_data->tag[0] == 0)
        break;

        unsigned char size_bytes[4];
        if (fread(size_bytes, 1, 4, f1) < 4) 
        break;

        meta_data->size = (size_bytes[0] << 24) | 
                              (size_bytes[1] << 16) |
                              (size_bytes[2] << 8) | 
                              size_bytes[3];

        char flags[2];
        if (fread(flags, 1, 2, f1) < 2)     
        break;

        if(strcmp(meta_data->tag, frame) == 0)
        {
            fwrite(meta_data->tag, 1, 4, f2);

            int size = strlen(new_data) + 1;

            unsigned char new_size[4] = {(size >> 24) & 0xFF,
                                         (size >> 16) & 0xFF,
                                         (size >> 8) & 0xFF,
                                          size & 0xFF};
            fwrite(new_size, 1, 4, f2);
            fwrite(flags, 1, 2, f2);

            unsigned char encoding = 0x00; 
            fwrite(&encoding, 1, 1, f2);
            fwrite(new_data, 1, strlen(new_data), f2);

            printf(GREEN "✅Updated %s successfully!\033[0m\n" RESET, frame);

            fseek(f1, meta_data->size, SEEK_CUR);
        }
        else
        {
            fwrite(meta_data->tag, 1, 4, f2);
            fwrite(size_bytes, 1, 4, f2);
            fwrite(flags, 1, 2, f2);

            char *buffer = malloc(meta_data->size);
            fread(buffer, 1, meta_data->size, f1);
            fwrite(buffer, 1, meta_data->size, f2);
            free(buffer);
        }
    }

    char buf[1024];
    size_t bytes;
    while ((bytes = fread(buf, 1, sizeof(buf), f1)) > 0)
    {
        fwrite(buf, 1, bytes, f2);
    }

    fclose(f1);
    fclose(f2);

    remove(name);
    rename("new.mp3", name);

    printf("\n\n");
}

void to_edit(struct mp3_tag *meta_data)
{
    char name[30];
    printf("Enter the "YELLOW "Audio file name: " RESET);
    scanf(" %29[^\n]", name);
    
    if(!validate_name(name))
    {
        printf(RED "❌ Invalid file name!\n\n" RESET);
        return;
    }

    int choice;
    while (1)
    {
        printf("\n==========EDIT TAG DETAILS==========\n");
        printf(YELLOW "1. Title\n");
        printf("2. Artist\n");
        printf("3. Album\n");
        printf("4. Year\n");
        printf("5. Track\n");
        printf("6. Composer\n");
        printf("7. Lyricist\n");
        printf("8. Genre\n" RESET);
        printf(BLUE "Enter your choice (1-8): " RESET);

        if (scanf("%d", &choice) != 1)
        {
            printf(RED "⚠Invalid input! Please enter a number between 1 and 8\n" RESET);
            while (getchar() != '\n');
            continue;
        }

        if (choice < 1 || choice > 8)
        {
            printf(RED "⚠Invalid choice! Please enter between 1 and 8.\n" RESET);
            continue;
        }

        break;
    }

    char new_data[30];
    switch(choice)
    {
        case 1:
        printf("\n===============EDIT TITLE===============\n");
        printf("Enter the \033[1;35mnew title name : \033[0m");
        scanf(" %[^\n]", new_data);
        update(meta_data, new_data, name, "TIT2");
        break;

        case 2:
        printf("\n===============EDIT ARTIST===============");
        printf("Enter the \033[1;35mnew Artist name : \033[0m");
        scanf(" %[^\n]", new_data);
        update(meta_data, new_data, name, "TPE1");
        break;

        case 3:
        printf("\n===============EDIT ALBUM===============");
        printf("Enter the \033[1;35mnew Album name : \033[0m");
        scanf(" %[^\n]", new_data);
        update(meta_data, new_data, name, "TALB");
        break;

        case 5:
        printf("\n===============EDIT TRACK NUMBER===============");
        printf("Enter the \033[1;35mnew TRACK number : \033[0m");
        scanf(" %[^\n]", new_data);
        update(meta_data, new_data, name, "TRCK");
        break;

        case 4:
        printf("\n===============EDIT YEAR===============");
        printf("Enter the \033[1;35mnew Year : \033[0m");
        scanf(" %[^\n]", new_data);
        update(meta_data, new_data, name, "TYER");
        break;

        case 8:
        printf("\n===============EDIT GENRE===============");
        printf("Enter the \033[1;35mnew Genre : \033[0m");
        scanf(" %[^\n]", new_data);
        update(meta_data, new_data, name, "TCON");
        break;

        case 6:
        printf("\n===============EDIT COMPOSER===============");
        printf("Enter the \033[1;35mnew composer name : \033[0m");
        scanf(" %[^\n]", new_data);
        update(meta_data, new_data, name, "TCOM");
        break;

        case 7:
        printf("\n===============EDIT LYRICISt===============");
        printf("Enter the \033[1;35mnew Lyricist name : \033[0m");
        scanf(" %[^\n]", new_data);
        update(meta_data, new_data, name, "TEXT");
        break;

        default:
        printf("\033[1;33mChoose the correct option: \033[0m");
    }

    
}