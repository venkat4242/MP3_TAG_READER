#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "tag.h"
#define RED "\033[1;31m"
#define GREEN "\033[1;32m"
#define YELLOW "\033[1;33m"
#define BLUE "\033[1;34m"
#define RESET "\033[0m"

int validate_name(const char *str)
{
    int len = strlen(str);
    if(len < 4) return 0;
    return strcmp(str + len - 4, ".mp3") == 0;
}

void to_view(struct mp3_tag *meta_data)
{
    printf("\n----------🎵 MP3 TAG VIEWER 🎵-----------------------\n");

    char name[256];

    while(1)
    {
        printf("\nEnter file name  (or 'exit' to quit): ");
        fflush(stdout);
        scanf(" %255[^\n]", name);

        if(strcmp(name, "exit") == 0 || strcmp(name, "EXIT") == 0)
            break;

        if(!validate_name(name))
        {
            printf(RED "❌ Invalid filename!\n" RESET);
            continue;
        }

        FILE *f = fopen(name, "rb");
        if(!f)
        {
            printf(RED "❌ Could not open file: %s\n" RESET, name);
            continue;
        }

        fseek(f, 10, SEEK_SET); 
        printf(BLUE "\n================ Song Details ================\n");

        for(int i = 0; i < 6; i++)
        {
            if(fread(meta_data->tag, 1, 4, f) != 4) break;
            meta_data->tag[4] = '\0';

            unsigned char size_bytes[4];
            if(fread(size_bytes, 1, 4, f) != 4) break;

            int frame_size = (size_bytes[0]<<24) | (size_bytes[1]<<16) | (size_bytes[2]<<8) | size_bytes[3];
            fseek(f, 2, SEEK_CUR);

            meta_data->tag_data = malloc(frame_size+1);
            if(!meta_data->tag_data) break;

            if(fread(meta_data->tag_data, 1, frame_size, f) != frame_size)
            {
                free(meta_data->tag_data);
                break;
            }
            meta_data->tag_data[frame_size] = '\0';

            if(strcmp(meta_data->tag,"TIT2")==0)      printf(YELLOW "Title    : "RESET "%s\n"  , meta_data->tag_data+1);
            else if(strcmp(meta_data->tag,"TPE1")==0) printf(YELLOW "Artist   : "RESET "%s\n", meta_data->tag_data+1);
            else if(strcmp(meta_data->tag,"TALB")==0) printf(YELLOW "Album    : "RESET "%s\n", meta_data->tag_data+1);
            else if(strcmp(meta_data->tag,"TYER")==0) printf(YELLOW "Year     : "RESET "%s\n", meta_data->tag_data+1);
            else if(strcmp(meta_data->tag,"TRCK")==0) printf(YELLOW "Track    : "RESET "%s\n", meta_data->tag_data+1);
            else if(strcmp(meta_data->tag,"TCOM")==0) printf(YELLOW "Composer : "RESET "%s\n", meta_data->tag_data+1);
            else if(strcmp(meta_data->tag,"TEXT")==0) printf(YELLOW "Lyricist : "RESET "%s\n", meta_data->tag_data+1);
            else if(strcmp(meta_data->tag,"TCON")==0) printf(YELLOW "Genre    : "RESET "%s\n", meta_data->tag_data+1);

            free(meta_data->tag_data);
        }

        printf("--------------------------------------------\n" RESET);
        fclose(f);
    }
    printf(GREEN "\nExiting MP3 Viewer...\n" RESET);
}
